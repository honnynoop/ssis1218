package org.ssis.edu.board.model;

import lombok.Data;

@Data
public class FileInfoDto {

	private String saveFolder;
	private String originalFile;
	private String saveFile;

}
