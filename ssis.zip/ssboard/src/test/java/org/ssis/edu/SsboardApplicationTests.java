package org.ssis.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
